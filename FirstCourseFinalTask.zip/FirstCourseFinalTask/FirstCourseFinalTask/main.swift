//
//  main.swift
//  FirstCourseFinalTask
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

import Foundation
import FirstCourseFinalTaskChecker

public class Users: UsersStorageProtocol {
    
    typealias Identifier = GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>
    //Структура поддерживаящая UserProtocol и хранилище
    private struct User: UserProtocol {
        
        var storage: [UserInitialData]?
        var currentUserID: Identifier?
        var followers: [(Identifier, Identifier)]?
        
        var id: Self.Identifier = ""
        var username: String = ""
        var fullName: String = ""
        var avatarURL: URL?
        
        var currentUserFollowsThisUser: Bool {
                var returnValue = false
                for (id1, id2) in followers! {
                    if id1 == currentUserID && id2 == id { returnValue = true }
                           }
                return returnValue
        }
        
        var currentUserIsFollowedByThisUser: Bool {
                var returnValeu = false
                for (id1, id2) in followers! {
                    if id1 == id && id2 == currentUserID { returnValeu = true }
                          }
                return returnValeu
        }
        
        var followsCount: Int {
                var returnValeu = 0
                for (id1, _) in followers! {
                    if id1 == id { returnValeu += 1}
                         }
                   return returnValeu
        }
        
        var followedByCount: Int {
                var returnValeu = 0
                for (_, id2) in followers! {
                    if id2 == id { returnValeu += 1}
                         }
                    return returnValeu
        }
        
    }
    /// Инициализатор хранилища. Принимает на вход массив пользователей, массив подписок в
       /// виде кортежей в котором первый элемент это ID, а второй - ID пользователя на которого он
       /// должен быть подписан и ID текущего пользователя.
       /// Инициализация может завершится с ошибкой если пользователя с переданным ID
       /// нет среди пользователей в массиве users.
    
        
         
    private var user: User

    required public init?(users: [UserInitialData],
                          followers: [(GenericIdentifier<UserProtocol>, GenericIdentifier<UserProtocol>)],
                          currentUserID: GenericIdentifier<UserProtocol>) {
        
        guard users.isEmpty != true else{ return nil }
        
        guard users.contains(where: {$0.id == currentUserID}) else{ return nil }
        
        user = User(storage: users, currentUserID: currentUserID, followers: followers)
    }
  
    
    
    /// Количество пользователей в хранилище.
    public var count: Int { return user.storage!.count }

    /// Возвращает текущего пользователя.
    ///
    /// - Returns: Текущий пользователь.
    public func currentUser() -> FirstCourseFinalTaskChecker.UserProtocol {
        //Так как текущий пользователь будет всегда иначе не сработает init, то выполнение filter выдаст только одно значение и будет помещенно в первый индекс массива, то есть нулевой
       let a =  user.storage!.filter{ $0.id == user.currentUserID }
        user.id = a[0].id
        user.fullName = a[0].fullName
        user.username = a[0].username
        return user
    }

    /// Возвращает пользователя с переданным ID.
    ///
    /// - Parameter userID: ID пользователя которого нужно вернуть.
    /// - Returns: Пользователь если он был найден.
    /// nil если такого пользователя нет в хранилище.
    public func user(with userID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> FirstCourseFinalTaskChecker.UserProtocol? {
        
        //Тот же принцип, что и в прошлой функции
         let a =  user.storage!.filter{ $0.id == userID }
        guard a.isEmpty != true else { return nil }
            user.id = a[0].id
            user.fullName = a[0].fullName
            user.username = a[0].username
        return user
    }

    /// Возвращает всех пользователей, содержащих переданную строку.
    ///
    /// - Parameter searchString: Строка для поиска.
    /// - Returns: Массив пользователей. Если не нашлось ни одного пользователя, то пустой массив.
    public func findUsers(by searchString: String) -> [FirstCourseFinalTaskChecker.UserProtocol] {
        var buffer: [User]
        let a = user.storage!.filter{$0.username == searchString}
        if a.isEmpty {
                buffer = [User]()
            }else{
                buffer = [user]
                for (index, value) in a.enumerated() {
                    buffer[index].id = value.id
                    buffer[index].username = value.username
                    buffer[index].fullName = value.fullName
                }
            }
        return buffer
    }

    /// Добавляет текущего пользователя в подписчики.
    ///
    /// - Parameter userIDToFollow: ID пользователя на которого должен подписаться текущий пользователь.
    /// - Returns: true если текущий пользователь стал подписчиком пользователя с переданным ID
    /// или уже являлся им.
    /// false в случае если в хранилище нет пользователя с переданным ID.
    public func follow(_ userIDToFollow: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> Bool{
        
        guard (user.storage?.contains(where: {$0.id == userIDToFollow})) == true else { return false }
        
        guard (user.followers?.contains(where: {$0.0 == user.currentUserID && $0.1 == userIDToFollow})) != true else { return true }
            
        user.followers!.append((user.currentUserID!, userIDToFollow))
        
        return true
    }

    /// Удаляет текущего пользователя из подписчиков.
    ///
    /// - Parameter userIDToUnfollow: ID пользователя от которого должен отписаться текущий пользователь.
    /// - Returns: true если текущий пользователь перестал быть подписчиком пользователя с
    /// переданным ID или и так не являлся им.
    /// false в случае если нет пользователя с переданным ID.
    public func unfollow(_ userIDToUnfollow: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> Bool{
            
        guard (user.storage?.contains(where: {$0.id == userIDToUnfollow})) == true else { return false }
        
        guard (user.followers?.contains(where: {$0.0 == user.currentUserID && $0.1 == userIDToUnfollow})) == true else { return true }
        
//        user.followers!.removeAll(where: {$0.0 == user.currentUserID && $0.1 == userIDToUnfollow}) - так не получилось
        
        let a = (user.currentUserID, userIDToUnfollow)
        for (index,value) in user.followers!.enumerated() {
            if a == value { user.followers!.remove(at: index)}
        }
        return true
    }

    /// Возвращает всех подписчиков пользователя.
    ///
    /// - Parameter userID: ID пользователя подписчиков которого нужно вернуть.
    /// - Returns: Массив пользователей.
    /// Пустой массив если на пользователя никто не подписан.
    /// nil если такого пользователя нет.
    public func usersFollowingUser(with userID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> [FirstCourseFinalTaskChecker.UserProtocol]? {
        
        guard (user.storage?.contains(where: {$0.id == userID})) == true else { return nil }
        
        var buffer: [User]
        let a = user.followers!.filter{ $0.1 == userID }
        if a.isEmpty {
            buffer = [User]()
        } else {
            buffer = [user]
        for (index, value) in a.enumerated() {
            if index != 0 {buffer.append(user)}
            for element in user.storage! {
                if element.id == value.0 {
                    buffer[index].id = element.id
                    buffer[index].username = element.username
                    buffer[index].fullName = element.fullName
            }
            }
            }
        }
        return buffer
    }

    /// Возвращает все подписки пользователя.
    ///
    /// - Parameter userID: ID пользователя подписки которого нужно вернуть.
    /// - Returns: Массив пользователей.
    /// Пустой массив если он ни на кого не подписан.
    /// nil если такого пользователя нет.
    public func usersFollowedByUser(with userID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> [FirstCourseFinalTaskChecker.UserProtocol]? {
        
        guard (user.storage?.contains(where: {$0.id == userID})) == true else { return nil }
        
        var buffer: [User]
        let a = user.followers!.filter{$0.0 == userID}
        
        if a.isEmpty {
                   buffer = [User]()
               } else {
                   buffer = [user]
               for (index, value) in a.enumerated() {
                   if index != 0 { buffer.append(user) }
                   for element in user.storage! {
                       if element.id == value.1 {
                           buffer[index].id = element.id
                           buffer[index].username = element.username
                           buffer[index].fullName = element.fullName
                   }
                   }
                   }
               }
        return buffer
    }

}

public class Posts: PostsStorageProtocol {
    
     typealias Identifier2 = FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>
    typealias Identifier = FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>
    
    public struct Post: PostProtocol {
  
        init(id: Self.Identifier, author: GenericIdentifier<UserProtocol>,
            description: String, imageURL: URL, createdTime: Date, currentUserID: Identifier2, likes: [(Identifier2, Identifier)] ) {
            self.id = id
            self.author = author
            self.description = description
            self.imageURL = imageURL
            self.createdTime = createdTime
            self.currentUserLikesThisPost = {
                return likes.contains(where: {$0.0 == currentUserID && $0.1 == id}) }()
            self.likedByCount = { return likes.filter{$0.1 == id}.count  }()
        }
        public var id: Self.Identifier
        public var author: GenericIdentifier<UserProtocol>
        public var description: String
        public var imageURL: URL
        public var createdTime: Date
        public var currentUserLikesThisPost: Bool
        public var likedByCount: Int
    }
    
        var posts: [PostInitialData]
        var currentUserID: Identifier2
        var likes: [(Identifier2, Identifier)]
    

    /// Инициализатор хранилища. Принимает на вход массив публикаций, массив лайков в виде
    /// кортежей в котором первый - это ID пользователя, поставившего лайк, а второй - ID публикации
    /// на которой должен стоять этот лайк и ID текущего пользователя.
    required public init(posts: [FirstCourseFinalTaskChecker.PostInitialData], likes: [(FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>, FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>)], currentUserID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) {
        
        self.posts = posts
        self.currentUserID = currentUserID
        self.likes = likes
    }

    /// Количество публикаций в хранилище.
    public var count: Int { return posts.count }

    /// Возвращает публикацию с переданным ID.
    ///
    /// - Parameter postID: ID публикации которую нужно вернуть.
    /// - Returns: Публикация если она была найдена.
    /// nil если такой публикации нет в хранилище.
    public func post(with postID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>) -> FirstCourseFinalTaskChecker.PostProtocol? {
        
        guard posts.contains(where: { $0.id == postID }) else { return nil }
        
        let buffer = posts.filter{ $0.id == postID }
        
        let post = Post(id: postID, author: buffer[0].author, description: buffer[0].description, imageURL: buffer[0].imageURL, createdTime: buffer[0].createdTime, currentUserID: currentUserID, likes: likes)
        
        return post
    }

    /// Возвращает все публикации пользователя с переданным ID.
    ///
    /// - Parameter authorID: ID пользователя публикации которого нужно вернуть.
    /// - Returns: Массив публикаций.
    /// Пустой массив если пользователь еще ничего не опубликовал.
    public func findPosts(by authorID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>) -> [FirstCourseFinalTaskChecker.PostProtocol] {
        var post = [Post]()
        let buffer = posts.filter{ $0.author == authorID }
        
        if buffer.count == 0 {
            return post
        } else {
            for value in buffer {
                post.append(Post(id: value.id, author: value.author, description: value.description, imageURL: value.imageURL, createdTime: value.createdTime, currentUserID: currentUserID, likes: likes))
            }
        }
       return post
    }

    /// Возвращает все публикации, содержащие переданную строку.
    ///
    /// - Parameter searchString: Строка для поиска.
    /// - Returns: Массив публикаций.
    /// Пустой массив если нет таких публикаций.
    public func findPosts(by searchString: String) -> [FirstCourseFinalTaskChecker.PostProtocol] {
        let buffer = posts.filter{$0.description == searchString}
        var post = [Post]()
        if buffer.count == 0 {
            return post
        } else {
            for value in buffer {
                post.append(Post(id: value.id, author: value.author, description: value.description, imageURL: value.imageURL, createdTime: value.createdTime, currentUserID: currentUserID, likes: likes))
            }
        }
        return post
    }

    /// Ставит лайк от текущего пользователя на публикацию с переданным ID.
    ///
    /// - Parameter postID: ID публикации на которую нужно поставить лайк.
    /// - Returns: true если операция выполнена упешно или пользователь уже поставил лайк
    /// на эту публикацию.
    /// false в случае если такой публикации нет.
    public func likePost(with postID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>) -> Bool{
       
        guard posts.contains(where: { $0.id == postID }) else { return false }
        
        guard likes.contains(where: { $0.0 == currentUserID && $0.1 == postID }) else {
            likes.append((currentUserID, postID))
            return true
            }
        
        return true
    }

    /// Удаляет лайк текущего пользователя у публикации с переданным ID.
    ///
    /// - Parameter postID: ID публикации у которой нужно удалить лайк.
    /// - Returns: true если операция выполнена успешно или пользователь и так не ставил лайк
    /// на эту публикацию.
    /// false в случае если такой публикации нет.
    public func unlikePost(with postID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>) -> Bool{
       
        guard posts.contains(where: { $0.id == postID }) else { return false }
        
        guard likes.contains(where: { $0.0 == currentUserID && $0.1 == postID }) else { return true }
        likes.removeAll(where: { $0.0 == currentUserID && $0.1 == postID })
        
        return true
    }

    /// Возвращает ID пользователей поставивших лайк на публикацию.
    ///
    /// - Parameter postID: ID публикации лайки на которой нужно искать.
    /// - Returns: Массив ID пользователей.
    /// Пустой массив если никто еще не поставил лайк на эту публикацию.
    /// nil если такой публикации нет в хранилище.
    public func usersLikedPost(with postID: FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.PostProtocol>) -> [FirstCourseFinalTaskChecker.GenericIdentifier<FirstCourseFinalTaskChecker.UserProtocol>]? {
       
        guard posts.contains(where: { $0.id == postID }) else { return nil }
        
        let buffer = likes.filter{$0.1 == postID}
        var post = [Identifier2]()
        
        if buffer.count == 0 {
            return post
        } else {
            for (id,_) in buffer {
               post.append(id)
            }
        }
        return post
    }
}



let checker = Checker(usersStorageClass: Users.self,
                      postsStorageClass: Posts.self)
checker.run()

